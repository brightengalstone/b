# BG Smart Services — UI upgrade

Next.js foundation for BG Smart Services, the Eersterust local shopping and delivery platform.

## Included
- New BG Smart Services homepage and visual system
- Marketplace search, categories, local business cards and products
- Functional browser cart with quantity controls
- Checkout foundation with R60 delivery + R45 service fees
- Supabase email/password authentication and password reset
- Account, admin, merchant, driver and tracking route foundations
- Responsive mobile layout

## Rules
- Delivery zone: Eersterust only
- Delivery fee: R60
- Service fee: R45

## Environment
Set:
- NEXT_PUBLIC_SUPABASE_URL
- NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY

Do not put a service-role/secret key in NEXT_PUBLIC_ variables.

## Run
npm install
npm run dev

## Production note
Role authorization and order/payment creation must be enforced server-side before accepting real production orders or payments.
