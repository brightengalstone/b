import './globals.css';
import Link from 'next/link';
export const metadata={title:'BG Smart Services',description:'Local shopping, delivered in Eersterust'};
export default function Layout({children}){return <><header><Link href="/" className="brand"><span>BG</span><div><b>BG Smart Services</b><small>Local delivery in Eersterust</small></div></Link><nav><Link href="/marketplace">Marketplace</Link><Link href="/signin">Sign in</Link><Link href="/account">Account</Link><Link href="/cart">Cart</Link></nav></header><main>{children}</main><footer><div><b>BG Smart Services</b><span>Local shopping, delivered in Eersterust.</span></div><span>Eersterust only • R60 delivery • R45 service</span></footer></>}
